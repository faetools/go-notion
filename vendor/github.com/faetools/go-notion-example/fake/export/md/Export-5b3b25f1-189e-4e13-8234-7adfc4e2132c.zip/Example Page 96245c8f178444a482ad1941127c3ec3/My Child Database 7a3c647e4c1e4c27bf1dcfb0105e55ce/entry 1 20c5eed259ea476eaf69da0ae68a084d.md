# entry 1

A number: 31.3
Equal relation: Untitled%20c85a632944c04a8f98d40ddd0e756b10.md
Money: 3
My checkbox: No
Property: +1-202-555-0146
Property checkbox: No
Status: I've taken a look
Sub: entry%203%2045d81ac0bf714a31b096941dd050f3e1.md
contact: mark@faetools.com
count of relations: 1
date formula: July 30, 2022
equal relations: 0
files: https://www.princeton.edu/sites/default/files/styles/full_2x/public/images/2022/02/KOA_Nassau_2697x1517.jpg?itok=Hy5eTACi, dog.webp
formula: no
formula number: 31.3
meme links: https://www.reddit.com/r/wholesomememes/
number with commas: 3.333
people: Fae Tools
rollup date: 1
select: foo
some date: July 30, 2022
tags: tag 1, tag 2, tag 3
text property: foo
when it was created: July 14, 2022 8:03 PM
who created it: Fae Tools
who last edited it: Fae Tools
yes or no?: No